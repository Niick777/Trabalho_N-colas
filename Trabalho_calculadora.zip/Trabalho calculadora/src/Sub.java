import java.util.Scanner;


public class Sub {
	
	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner entrada = new Scanner(System.in);
		
		int numero1=0;
		int numero2=0;
		int sub=0;
		
		System.out.print("Digite o primeiro n�mero: ");
		numero1 = entrada.nextInt();
		
		System.out.print("Digite o segundo n�mero: ");
		numero2 = entrada.nextInt();
		
		sub = numero1-numero2;
		System.out.printf("O resultado da subtra��o �: %d\n", sub);
	}

}
