import java.util.Scanner;


public class div {
	
	private static Scanner entrada;

	public static void main(String[] args) {
		
		entrada = new Scanner(System.in);
		
		int numero1=0;
		int numero2=0;
		int div=0;
		
		System.out.print("Digite o primeiro n�mero: ");
		numero1 = entrada.nextInt();
		System.out.print("Digite o segundo n�mero: ");
		numero2 = entrada.nextInt();
		
		div = numero1/numero2;
		System.out.printf("O resultado da divis�o �: %d\n", div);
	}

}
