import java.util.Scanner;


public class mult {
	
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		
		Scanner entrada = new Scanner(System.in);
		
		int numero1=0;
		int numero2=0;
		int mult=0;
		
		System.out.print("Digite o primeiro n�mero: ");
		numero1 = entrada.nextInt();
		System.out.print("Digite o segundo n�mero: ");
		numero2 = entrada.nextInt();
		
		mult = numero1*numero2;
		System.out.printf("O resultado da multiplica��o �: %d\n", mult);
				
	}

}
