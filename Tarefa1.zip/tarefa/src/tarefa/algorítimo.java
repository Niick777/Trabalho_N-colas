package tarefa;

import java.util.Scanner;

public class algor�timo {
	
	private static Scanner entrada;

	public static void main(String[] args) {
		
		entrada = new Scanner(System.in);
		
		String nome, cidade;
		int idade;
		
		System.out.printf("Oi, seja bem vindo! Qual o seu nome?");
		nome = entrada.nextLine();
		System.out.println("Ola "+nome+"! De onde voc� �?");
		cidade = entrada.nextLine();
		System.out.printf("Certo, quantos anos voc� tem "+nome+"?");
		idade = entrada.nextInt();
		System.out.printf("Ok! Ent�o voc� se chama "+nome+" veio de "+cidade+" e tem "+idade+" anos, prazer em te conhecer!");
		
	}
}
